import { GoogleGenAI } from "@google/genai";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateTopics = async (count: number = 40): Promise<string[]> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Genera una lista de ${count} palabras o conceptos aleatorios para improvisar rap (freestyle) en español. 
      Deben ser retadores, mezcla de objetos (micrófono, spray), conceptos abstractos (tiempo, honor), lugares (calle, tarima), emociones y situaciones bizarras. 
      Devuelve SOLO las palabras separadas por comas, sin numeración ni texto extra.`,
    });

    const text = response.text;
    if (!text) return ["Microfono", "Calle", "Ritmo", "Victoria", "Tiempo"];
    
    return text.split(',').map(s => s.trim()).filter(s => s.length > 0);
  } catch (error) {
    console.error("Error generating topics:", error);
    return ["Error", "Intenta", "De", "Nuevo", "Conexión"];
  }
};

export const generateTerminations = async (count: number = 40): Promise<string[]> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Genera una lista de ${count} terminaciones de rimas (sufijos o vocales) para practicar freestyle (Rap).
      Ejemplos: "A-O", "I-A", "-ÓN", "-EZ", "-URA", "E-O", "Á-TICOS", "O-A".
      Mezcla terminaciones fáciles (asonantes) y difíciles (consonantes).
      Devuelve SOLO las terminaciones separadas por comas, en mayúsculas, sin numeración.`,
    });

    const text = response.text;
    if (!text) return ["A-O", "I-A", "-ÓN", "E-O", "-ER"];
    
    return text.split(',').map(s => s.trim()).filter(s => s.length > 0);
  } catch (error) {
    console.error("Error generating terminations:", error);
    return ["A-O", "I-A", "Error", "-ÓN", "E-O"];
  }
};

export const generateCharacterBattles = async (count: number = 20): Promise<string[]> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Genera una lista de ${count} batallas de personajes o conceptos contrapuestos épicos para improvisación.
      Formato: "Concepto A vs Concepto B".
      Ejemplos: "Dios vs Diablo", "Sol vs Luna", "Naturaleza vs Tecnología", "Batman vs Joker", "León vs Tigre".
      Devuelve SOLO las parejas separadas por comas.`,
    });

    const text = response.text;
    if (!text) return ["Dios vs Diablo", "Sol vs Luna", "Fuego vs Hielo"];
    
    return text.split(',').map(s => s.trim()).filter(s => s.length > 0);
  } catch (error) {
    console.error("Error generating battles:", error);
    return ["Bien vs Mal", "Luz vs Oscuridad"];
  }
};

export const generateQuestions = async (count: number = 20): Promise<string[]> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Genera una lista de ${count} preguntas INCÓMODAS, PERSONALES y de 'CHISME' sobre la vida privada del oponente para una batalla de rap.
      
      REGLAS ESTRICTAS DE FORMATO:
      1. CADA PREGUNTA DEBE SER CORTA (Máximo 10-12 palabras).
      2. ELIMINA todo el contexto innecesario. Ve directo al grano.
      3. Menciona "tu rival", "tu oponente" o "este rapero".

      EJEMPLOS INCORRECTOS (Muy largos):
      X "¿Quién le paga la renta a este rapero ahora que vive solo y no tiene un peso?"
      X "¿Por qué tu rival sigue viviendo con su mamá a pesar de tener 30 años?"

      EJEMPLOS CORRECTOS (Cortos y Directos):
      ✓ "¿Quién le paga la renta a este rapero?"
      ✓ "¿Por qué tu rival sigue viviendo con su mamá?"
      ✓ "¿Quién le paga el internet a tu oponente?"
      ✓ "¿A qué se dedica tu oponente los lunes?"
      ✓ "¿Con quién comparte cuarto tu rival?"
      ✓ "¿Por qué nadie de su familia lo apoya?"
      ✓ "¿En qué gasta el poco dinero que tiene?"

      Devuelve SOLO las preguntas separadas por comas.`,
    });

    const text = response.text;
    if (!text) return ["¿Quién le paga la renta?", "¿Quién mantiene a tu oponente?", "¿Por qué no trabaja tu rival?"];
    
    return text.split(',').map(s => s.trim()).filter(s => s.length > 0);
  } catch (error) {
    console.error("Error generating questions:", error);
    return ["¿Quién es tu rival?", "¿Por qué tu oponente está aquí?"];
  }
};

export const generateTopicImage = async (topic: string): Promise<string | null> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { 
            text: `Genera una imagen visualmente impactante, creativa y única para servir como estímulo en una batalla de freestyle.
            No te limites al estilo urbano. Puede ser surrealista, fotorealista, cyberpunk, fantasía oscura, abstracta o cartoon.
            Representa visualmente el concepto: "${topic}".
            IMPORTANTE: NO incluyas texto en la imagen. Solo la imagen pura.` 
          }
        ],
      },
    });

    // Extract image from response
    if (response.candidates && response.candidates[0].content.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData && part.inlineData.data) {
          return `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
        }
      }
    }
    return null;
  } catch (error) {
    console.error("Error generating image:", error);
    return null;
  }
};

export const generateVotingBackground = async (): Promise<string | null> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { 
            text: `Genera una imagen épica para fondo de pantalla. 
            Tema: Un bufón (Jester) rapero o improvisando en un escenario oscuro y urbano.
            Estilo: Arte conceptual oscuro, neón, humo, alta definición, dramático.
            Colores: Predominantemente oscuro, con toques de morado y humo.
            Sin texto.` 
          }
        ],
      },
    });

    if (response.candidates && response.candidates[0].content.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData && part.inlineData.data) {
          return `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
        }
      }
    }
    return null;
  } catch (error) {
    console.error("Error generating voting bg:", error);
    return null;
  }
};

export const editImage = async (base64Image: string, prompt: string, mimeType: string): Promise<string | null> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image,
              mimeType: mimeType,
            },
          },
          {
            text: prompt,
          },
        ],
      },
    });

    // Extract image from response
    if (response.candidates && response.candidates[0].content.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData && part.inlineData.data) {
          return `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
        }
      }
    }
    return null;
  } catch (error) {
    console.error("Error editing image:", error);
    return null;
  }
};