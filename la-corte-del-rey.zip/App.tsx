
import React, { useState, useEffect } from 'react';
import { TopicGenerator } from './components/TopicGenerator';
import { SlotMachine } from './components/SlotMachine';
import { TournamentBracket } from './components/TournamentBracket';
import { Info, Image as ImageIcon, RotateCcw, Youtube, Play, ExternalLink, User, Crown, Trophy, Zap, Swords, BookOpen, X, List, Scale, Timer, Star, Award } from 'lucide-react';
import { TrainingFormat, TrainingMode, BeatGenre, ALL_TRAINING_MODES } from './types';
import { generateTopics, generateTopicImage, generateTerminations, generateCharacterBattles, generateQuestions, generateVotingBackground } from './services/geminiService';

// Updated steps: replaced format/mode/beat with 'slots'
type AppStep = 'names' | 'slots' | 'summary' | 'arena' | 'voting';

const MODE_TRANSLATIONS: Record<string, string> = {
    themes: 'TEMÁTICAS',
    free: 'SANGRE',
    terminations: 'TERMINACIONES',
    characters: 'PERSONAJES',
    questions: 'PREGUNTAS'
};

const ENTRADAS_RULES: Record<string, string> = {
  [TrainingFormat.FOUR_BY_FOUR]: "5 Entradas por MC",
  [TrainingFormat.EIGHT_BY_EIGHT]: "3 Entradas por MC",
  [TrainingFormat.TWO_BY_TWO]: "10 Entradas por MC",
  [TrainingFormat.MINUTE]: "5 Entradas por MC",
  [TrainingFormat.KICK_BACK]: "5 Entradas por MC"
};

const App: React.FC = () => {
  const [step, setStep] = useState<AppStep>('names'); // Start at names
  const [rivalA, setRivalA] = useState('');
  const [rivalB, setRivalB] = useState('');
  const [winner, setWinner] = useState<'A' | 'B' | null>(null);
  const [showWinnerScreen, setShowWinnerScreen] = useState(false);
  
  // Replica (Tie) State
  const [isReplica, setIsReplica] = useState(false);

  const [selectedFormat, setSelectedFormat] = useState<TrainingFormat | null>(null);
  const [selectedMode, setSelectedMode] = useState<TrainingMode>('themes');
  const [selectedGenre, setSelectedGenre] = useState<BeatGenre | null>(null);
  const [countdown, setCountdown] = useState<string | null>(null);
  
  // Transition State
  const [isTransitioning, setIsTransitioning] = useState(false);
  
  // Pre-generated Content State
  const [preGeneratedTopic, setPreGeneratedTopic] = useState<string | null>(null);
  const [preGeneratedImage, setPreGeneratedImage] = useState<string | null>(null);
  const [preGeneratedPool, setPreGeneratedPool] = useState<string[]>([]);
  const [isPreGenerating, setIsPreGenerating] = useState(false);

  // Voting Background State
  const [votingBg, setVotingBg] = useState<string | null>(null);
  const [isGeneratingVotingBg, setIsGeneratingVotingBg] = useState(false);

  // Info Modal State
  const [showInfoModal, setShowInfoModal] = useState(false);
  const [showTournamentModal, setShowTournamentModal] = useState(false);

  // Safety: Ensure transition doesn't get stuck
  useEffect(() => {
    if (isTransitioning) {
        const timer = setTimeout(() => {
            setIsTransitioning(false);
        }, 2000); // Force off after 2s max
        return () => clearTimeout(timer);
    }
  }, [isTransitioning]);

  // Centralized Navigation with Lightning Effect
  const changeStepWithTransition = (nextStep: AppStep) => {
    setIsTransitioning(true);
    
    // Change content MID-ANIMATION (while screen is flashed white) to hide the swap
    setTimeout(() => {
        setStep(nextStep);
    }, 350);

    // Remove overlay after animation completes
    setTimeout(() => {
        setIsTransitioning(false);
    }, 850);
  };

  const handleNamesSubmit = () => {
      // Set defaults if empty
      if (!rivalA.trim()) setRivalA("MC AZUL");
      if (!rivalB.trim()) setRivalB("MC ROJO");
      changeStepWithTransition('slots');
  };

  const handleRouletteComplete = (format: TrainingFormat, mode: TrainingMode, genre: BeatGenre) => {
      setSelectedFormat(format);
      setSelectedMode(mode);
      setSelectedGenre(genre);
      // Wait a tiny bit to see the result then move
      setTimeout(() => {
          changeStepWithTransition('summary');
      }, 500);
  };

  // Pre-generate content when entering Summary step
  useEffect(() => {
    if (step === 'summary') {
        const prepareContent = async () => {
            setIsPreGenerating(true);
            setPreGeneratedTopic(null);
            setPreGeneratedImage(null);
            setPreGeneratedPool([]);

            if (selectedMode === 'themes') {
                // Generate topics, pick one, AND generate image for it
                const topics = await generateTopics(40);
                setPreGeneratedPool(topics);
                const randomTopic = topics[Math.floor(Math.random() * topics.length)];
                setPreGeneratedTopic(randomTopic);
                
                // Pre-fetch image for this topic
                const img = await generateTopicImage(randomTopic);
                setPreGeneratedImage(img);

            } else if (selectedMode === 'terminations') {
                const terms = await generateTerminations(40);
                setPreGeneratedPool(terms); // Save full list
                const randomTerm = terms[Math.floor(Math.random() * terms.length)];
                setPreGeneratedTopic(randomTerm);

            } else if (selectedMode === 'questions') {
                const questions = await generateQuestions(20);
                setPreGeneratedPool(questions);
                const randomQuestion = questions[Math.floor(Math.random() * questions.length)];
                setPreGeneratedTopic(randomQuestion);

            } else if (selectedMode === 'characters') {
                const battles = await generateCharacterBattles(20);
                setPreGeneratedPool(battles);
                const randomBattle = battles[Math.floor(Math.random() * battles.length)];
                setPreGeneratedTopic(randomBattle); 
                const img = await generateTopicImage(randomBattle);
                setPreGeneratedImage(img);
            }
            setIsPreGenerating(false);
        };
        prepareContent();
    }
  }, [step, selectedMode]);

  // Generate Voting Background when entering Arena
  useEffect(() => {
    if (step === 'arena') {
        const prepareVotingBg = async () => {
            setIsGeneratingVotingBg(true);
            setVotingBg(null);
            const bg = await generateVotingBackground();
            setVotingBg(bg);
            setIsGeneratingVotingBg(false);
        };
        prepareVotingBg();
    }
  }, [step]);

  const resetApp = () => {
    setStep('names');
    setSelectedFormat(null);
    setSelectedGenre(null);
    setPreGeneratedTopic(null);
    setPreGeneratedImage(null);
    setPreGeneratedPool([]);
    setWinner(null);
    setShowWinnerScreen(false);
    setRivalA('');
    setRivalB('');
    setVotingBg(null);
    setIsReplica(false);
  };

  const openYoutubeBeat = () => {
    if (!selectedGenre) return;
    // Updated search query format
    const query = encodeURIComponent(`${selectedGenre} instrumental freestyle`);
    const url = `https://www.youtube.com/results?search_query=${query}`;
    
    // Open in a small popup window (Mini Pestaña)
    const width = 500;
    const height = 600;
    const left = (window.screen.width - width) / 2;
    const top = (window.screen.height - height) / 2;
    
    window.open(
        url, 
        'YoutubeBeatWindow', 
        `width=${width},height=${height},top=${top},left=${left},toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes`
    );
  };

  const handleStartBattle = () => {
      triggerCountdown();
  };

  const handleFinishBattle = () => {
      changeStepWithTransition('voting');
  };

  const handleVote = (vote: 'A' | 'B') => {
      setWinner(vote);
      // Wait for execution animation to finish before showing the winner screen
      setTimeout(() => {
          setShowWinnerScreen(true);
      }, 3000); // 3 seconds delay for dramatic effect
  };

  const handleReplica = () => {
      setIsReplica(true);
      changeStepWithTransition('slots'); // Go back to slots, but now in Replica mode
  };

  const triggerCountdown = () => {
    if (countdown) return;

    let count = 3;
    setCountdown(count.toString());

    // Faster countdown (400ms instead of 600ms)
    const interval = setInterval(() => {
      count--;
      if (count > 0) {
        setCountdown(count.toString());
      } else if (count === 0) {
        setCountdown("¡TIEMPO!");
      } else {
        clearInterval(interval);
        setTimeout(() => {
          setCountdown(null);
          setStep('arena'); // Switch to Arena AFTER countdown
        }, 400); 
      }
    }, 400); 
  };

  // Determine background to use (Generated or Fallback)
  const bgToUse = votingBg || "https://images.unsplash.com/photo-1533174072545-e8d4aa97edf9?q=80&w=1920&auto=format&fit=crop";

  return (
    <div className={`min-h-screen bg-gradient-to-b text-white p-4 md:p-6 lg:p-8 overflow-x-hidden relative flex flex-col ${isReplica && step === 'slots' ? 'from-red-950 to-black' : 'from-[#1a0b2e] to-[#0d001a]'}`}>
      
      {/* --- TOP RIGHT BUTTONS --- */}
      <div className="fixed top-4 right-4 z-[90] flex items-center gap-2">
          {/* TOURNAMENT BUTTON */}
          <button 
            onClick={() => setShowTournamentModal(true)}
            className="bg-black/40 backdrop-blur-md border border-yellow-500/50 hover:bg-yellow-900/50 hover:border-yellow-400 text-yellow-200 p-3 rounded-full shadow-[0_0_15px_rgba(234,179,8,0.3)] transition-all transform hover:scale-105"
            title="Modo Torneo"
          >
            <Trophy size={24} />
          </button>

          {/* MANUAL/INFO BUTTON */}
          <button 
            onClick={() => setShowInfoModal(true)}
            className="bg-black/40 backdrop-blur-md border border-purple-500/50 hover:bg-purple-900/50 hover:border-green-400 text-purple-200 p-3 rounded-full shadow-[0_0_15px_rgba(168,85,247,0.3)] transition-all transform hover:scale-105"
            title="Ver opciones disponibles"
          >
            <List size={24} />
          </button>
      </div>

      {/* TOURNAMENT MODAL - Persisted using 'hidden' class to prevent unmount and state loss */}
      <div className={`fixed inset-0 z-[160] bg-black/95 backdrop-blur-lg items-center justify-center p-4 animate-fadeIn ${showTournamentModal ? 'flex' : 'hidden'}`}>
          <div className="bg-[#1a0b2e] w-full max-w-6xl h-[90vh] rounded-2xl border-2 border-yellow-600 shadow-[0_0_50px_rgba(234,179,8,0.3)] overflow-hidden flex flex-col relative">
              <div className="absolute top-4 right-4 z-50">
                  <button 
                    onClick={() => setShowTournamentModal(false)}
                    className="text-gray-400 hover:text-white hover:bg-red-500/20 p-2 rounded-full transition-colors"
                  >
                    <X size={28} />
                  </button>
              </div>
              <TournamentBracket />
          </div>
      </div>

      {/* INFO MODAL OVERLAY */}
      {showInfoModal && (
        <div className="fixed inset-0 z-[150] bg-black/90 backdrop-blur-lg flex items-center justify-center p-4 animate-fadeIn">
            <div className="bg-[#1a0b2e] w-full max-w-4xl max-h-[90vh] rounded-2xl border-2 border-purple-500 shadow-[0_0_50px_rgba(168,85,247,0.5)] overflow-hidden flex flex-col relative">
                
                {/* Modal Header */}
                <div className="p-6 border-b border-purple-800 flex justify-between items-center bg-purple-950/50">
                    <div className="flex items-center gap-3">
                        <BookOpen className="text-green-400" />
                        <h2 className="text-2xl font-urban text-white tracking-widest uppercase">Manual de Juego</h2>
                    </div>
                    <button 
                        onClick={() => setShowInfoModal(false)}
                        className="text-gray-400 hover:text-white hover:bg-red-500/20 p-2 rounded-full transition-colors"
                    >
                        <X size={28} />
                    </button>
                </div>

                {/* Modal Content */}
                <div className="p-6 overflow-y-auto custom-scrollbar grid grid-cols-1 md:grid-cols-3 gap-6">
                    
                    {/* Column 1: Formats */}
                    <div className="space-y-4">
                        <h3 className="text-purple-300 font-bold uppercase tracking-widest border-b border-purple-700 pb-2">Formatos</h3>
                        <div className="space-y-2">
                            {Object.values(TrainingFormat).map((fmt) => (
                                <div key={fmt} className="bg-purple-900/20 p-3 rounded-lg border border-purple-800/50 text-gray-200 text-sm font-bold flex justify-between">
                                    <span>{fmt}</span>
                                    <span className="text-purple-400 text-xs">{ENTRADAS_RULES[fmt]?.replace(' Entradas por MC', 'e')}</span>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Column 2: Stimuli */}
                    <div className="space-y-4">
                        <h3 className="text-pink-300 font-bold uppercase tracking-widest border-b border-pink-700 pb-2">Estímulos</h3>
                        <div className="space-y-2">
                            {ALL_TRAINING_MODES.map((mode) => (
                                <div key={mode} className="bg-pink-900/20 p-3 rounded-lg border border-pink-800/50 text-gray-200 text-sm font-bold capitalize">
                                    {MODE_TRANSLATIONS[mode] || mode}
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Column 3: Beats */}
                    <div className="space-y-4">
                        <h3 className="text-blue-300 font-bold uppercase tracking-widest border-b border-blue-700 pb-2">Estilos de Beat</h3>
                        <div className="space-y-2">
                            {Object.values(BeatGenre).map((beat) => (
                                <div key={beat} className="bg-blue-900/20 p-3 rounded-lg border border-blue-800/50 text-gray-200 text-sm font-bold">
                                    {beat}
                                </div>
                            ))}
                        </div>
                    </div>

                </div>

                <div className="p-4 bg-purple-950/30 text-center text-xs text-gray-500 border-t border-purple-800">
                    Todas las opciones tienen la misma probabilidad en la Ruleta del Destino.
                </div>
            </div>
        </div>
      )}

      {/* Transition Overlay (Lightning Effect) */}
      {isTransitioning && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center pointer-events-none">
            {/* Flash Background - Full Opacity to hide transition */}
            <div className="absolute inset-0 bg-white animate-flash-storm mix-blend-overlay"></div>
            <div className={`absolute inset-0 animate-flash-storm ${isReplica ? 'bg-red-600' : 'bg-purple-600'}`}></div>
            
            {/* Lightning Icon */}
            <div className="relative z-10 animate-strike">
                <Zap size={250} className={`${isReplica ? 'text-red-500' : 'text-purple-500'} drop-shadow-[0_0_80px_currentColor]`} fill="currentColor" />
            </div>
        </div>
      )}

      {/* Countdown Overlay (Main Battle) */}
      {countdown && (
        <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center animate-fadeInFast">
            <h1 className="text-6xl sm:text-8xl md:text-[10rem] lg:text-[15rem] font-black font-urban text-transparent bg-clip-text bg-gradient-to-br from-purple-400 via-pink-500 to-indigo-600 drop-shadow-[0_10px_20px_rgba(168,85,247,0.5)] animate-scale-up tracking-tighter text-center break-words max-w-full px-4">
                {countdown}
            </h1>
        </div>
      )}

      <div className="max-w-6xl mx-auto w-full flex-1 flex flex-col">
        
        {/* Header - Hide during voting AND Arena to clean up UI */}
        {step !== 'voting' && step !== 'arena' && (
            <header className="text-center py-4 relative mb-4 flex flex-col items-center">
                <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[150%] blur-[100px] -z-10 rounded-full pointer-events-none ${isReplica ? 'bg-red-600/20' : 'bg-purple-600/10'}`}></div>
                
                {/* Crown Logo */}
                <div className="relative mb-2 animate-float">
                    <Crown size={48} className={`${isReplica ? 'text-red-500' : 'text-yellow-400'} drop-shadow-[0_0_15px_rgba(250,204,21,0.6)]`} fill={isReplica ? "rgba(220,38,38,0.2)" : "rgba(250,204,21,0.2)"} />
                </div>

                <h1 className="text-3xl md:text-5xl font-urban font-black tracking-tighter transform -rotate-2 relative z-10 animate-shine-text drop-shadow-xl">
                    LA CORTE DEL REY
                </h1>
                
                {/* Simple Breadcrumb (Hidden on Names Step) */}
                {step !== 'names' && step !== 'slots' && selectedFormat && (
                    <div className="inline-block mt-2 bg-purple-900/80 border border-purple-500 rounded-full px-4 py-1">
                        <p className="text-xs uppercase tracking-widest text-purple-200 font-bold">
                            {selectedFormat} 
                            {selectedMode && ` • ${MODE_TRANSLATIONS[selectedMode]}`}
                            {selectedGenre && ` • ${selectedGenre}`}
                        </p>
                    </div>
                )}
            </header>
        )}

        {/* Main Content Area */}
        <main className={`flex-1 flex flex-col justify-center animate-fadeIn relative min-h-0 ${step === 'voting' ? 'p-0' : ''} ${step === 'arena' ? 'justify-start md:justify-center' : ''}`}>
            
            {/* STEP 0: NAMES INPUT */}
            {step === 'names' && (
                <div className="w-full max-w-4xl mx-auto flex flex-col items-center justify-center flex-1 min-h-[50vh]">
                    <h2 className="text-2xl md:text-3xl font-urban text-white mb-8 text-center drop-shadow-lg tracking-widest uppercase animate-pulse px-4">
                        ¿QUIÉNES BATALLAN HOY?
                    </h2>

                    <div className="flex flex-col md:flex-row w-full gap-8 md:gap-4 items-center justify-center mb-10 relative">
                        {/* Rival A - Blue */}
                        <div className="w-full max-w-xs md:max-w-sm relative group z-10">
                            <div className="absolute inset-0 bg-blue-600/20 rounded-2xl blur-xl group-hover:bg-blue-500/40 transition-all"></div>
                            <div className="relative bg-black/80 border-2 border-blue-500 p-6 rounded-2xl shadow-[0_0_20px_rgba(59,130,246,0.3)]">
                                <div className="flex items-center gap-2 mb-2 text-blue-400 font-urban text-xl">
                                    <User size={24} />
                                    <span>BUFÓN AZUL</span>
                                </div>
                                <input 
                                    type="text" 
                                    value={rivalA}
                                    onChange={(e) => setRivalA(e.target.value)}
                                    placeholder="MC 1"
                                    className="w-full bg-transparent border-b-2 border-blue-800 focus:border-blue-400 outline-none text-2xl font-bold text-white py-2 placeholder-blue-900/50 uppercase tracking-wide text-center"
                                />
                            </div>
                        </div>

                        {/* VS BADGE */}
                        <div className="relative z-20 md:-mx-6 my-[-10px] md:my-0 flex-shrink-0">
                             <div className="w-16 h-16 bg-black border-2 border-purple-500 rotate-45 flex items-center justify-center shadow-[0_0_20px_rgba(168,85,247,0.5)]">
                                <span className="-rotate-45 text-2xl font-black text-white italic">VS</span>
                             </div>
                        </div>

                        {/* Rival B - Red */}
                        <div className="w-full max-w-xs md:max-w-sm relative group z-10">
                            <div className="absolute inset-0 bg-red-600/20 rounded-2xl blur-xl group-hover:bg-red-500/40 transition-all"></div>
                            <div className="relative bg-black/80 border-2 border-red-500 p-6 rounded-2xl shadow-[0_0_20px_rgba(239,68,68,0.3)]">
                                <div className="flex items-center gap-2 mb-2 text-red-400 font-urban text-xl justify-end">
                                    <span>BUFÓN ROJO</span>
                                    <User size={24} />
                                </div>
                                <input 
                                    type="text" 
                                    value={rivalB}
                                    onChange={(e) => setRivalB(e.target.value)}
                                    placeholder="MC 2"
                                    className="w-full bg-transparent border-b-2 border-red-800 focus:border-red-400 outline-none text-2xl font-bold text-white py-2 placeholder-red-900/50 uppercase tracking-wide text-center"
                                />
                            </div>
                        </div>
                    </div>

                    <button 
                        onClick={handleNamesSubmit}
                        className="group relative px-10 py-4 bg-gradient-to-r from-blue-600 to-red-600 rounded-xl font-black text-2xl uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-[0_0_30px_rgba(168,85,247,0.4)] overflow-hidden"
                    >
                         <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 skew-y-12"></div>
                         <span className="relative z-10 flex items-center gap-3">
                            <Swords size={28} />
                            CONTINUAR
                         </span>
                    </button>
                </div>
            )}

            {/* STEP 1 (NEW): ROULETTE / SLOTS */}
            {step === 'slots' && (
                <div className="w-full flex flex-col justify-center min-h-[60vh]">
                     {!isReplica && (
                         <button onClick={() => changeStepWithTransition('names')} className="mb-6 text-sm text-purple-400 hover:text-white uppercase font-bold tracking-widest flex items-center gap-1 mx-auto">← Volver</button>
                     )}
                     <SlotMachine onComplete={handleRouletteComplete} isReplica={isReplica} />
                </div>
            )}

            {/* STEP 2: PRE-BATTLE SUMMARY */}
            {step === 'summary' && (
                <div className="w-full max-w-2xl mx-auto flex flex-col items-center justify-center animate-fadeIn">
                    <h2 className="text-4xl font-urban text-white mb-8 text-center drop-shadow-lg">¿LISTO PARA LA BATALLA?</h2>
                    
                    <div className="w-full bg-purple-900/20 border border-purple-600/50 rounded-2xl p-6 mb-8 backdrop-blur-sm">
                        <h3 className="text-purple-300 uppercase text-xs font-bold tracking-widest mb-4">Resumen</h3>
                        <div className="grid grid-cols-2 gap-4 text-center">
                            <div className="bg-black/40 p-3 rounded-lg">
                                <p className="text-xs text-gray-400">Formato</p>
                                <p className="font-bold text-lg text-green-400">{selectedFormat}</p>
                            </div>
                            <div className="bg-black/40 p-3 rounded-lg">
                                <p className="text-xs text-gray-400">Estímulo</p>
                                <p className="font-bold text-lg text-pink-400">{MODE_TRANSLATIONS[selectedMode] || selectedMode}</p>
                            </div>
                            <div className="col-span-2 bg-black/40 p-3 rounded-lg border border-purple-500/30">
                                <p className="text-xs text-gray-400">Beat Style</p>
                                <p className="font-bold text-xl text-yellow-400">{selectedGenre}</p>
                            </div>
                        </div>
                    </div>

                    <div className="flex flex-col gap-4 w-full">
                        {/* 1. Open Beat */}
                        <button
                            onClick={openYoutubeBeat}
                            className="w-full py-4 bg-black border-2 border-red-600 text-red-500 hover:bg-red-600 hover:text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-[0_0_20px_rgba(220,38,38,0.2)] hover:shadow-[0_0_30px_rgba(220,38,38,0.5)]"
                        >
                            <Youtube size={24} />
                            ABRIR BEAT (MINI VENTANA)
                            <ExternalLink size={16} className="opacity-70" />
                        </button>
                        
                        <p className="text-center text-xs text-gray-400">Abre el beat y regresa para empezar</p>

                        {/* 2. Start Battle */}
                        <button
                            onClick={handleStartBattle}
                            disabled={isPreGenerating}
                            className={`w-full py-8 mt-4 rounded-xl font-black text-3xl font-urban tracking-wider flex items-center justify-center gap-3 transition-all transform active:scale-95 ${
                                isPreGenerating
                                ? 'bg-gray-800 text-gray-500 cursor-wait border-2 border-gray-700'
                                : 'bg-gradient-to-r from-blue-600 to-red-600 text-white shadow-[0_0_30px_rgba(37,99,235,0.4)] border-b-8 border-purple-900 hover:scale-[1.02]'
                            }`}
                        >
                            {isPreGenerating ? (
                                <>
                                    <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-gray-500"></div>
                                    {selectedMode === 'themes' ? 'GENERANDO ARTE...' : selectedMode === 'terminations' ? 'BUSCANDO RIMAS...' : selectedMode === 'characters' ? 'PREPARANDO DUELO...' : selectedMode === 'questions' ? 'PENSANDO PREGUNTA...' : 'BUSCANDO CONCEPTOS...'}
                                </>
                            ) : (
                                <>
                                    <Play size={32} fill="white" />
                                    ¡INICIAR BATALLA!
                                </>
                            )}
                        </button>
                    </div>

                    {!isReplica && (
                        <button 
                            onClick={() => changeStepWithTransition('slots')} 
                            className="mt-6 text-purple-400 hover:text-white underline text-sm"
                        >
                            Tirar Ruleta de Nuevo
                        </button>
                    )}
                </div>
            )}

            {/* STEP 5: ARENA (RE-DESIGNED LAYOUT) */}
            {step === 'arena' && (
                <div className="w-full h-full flex flex-col md:flex-row items-center md:items-stretch justify-center gap-4 md:gap-6 animate-fadeIn">
                    
                    {/* LEFT COLUMN: RIVAL A */}
                    <div className="w-full md:w-1/4 flex md:flex-col justify-between md:justify-center items-center order-2 md:order-1 gap-2 bg-blue-900/10 border border-blue-500/20 rounded-xl p-2 md:p-4">
                         <div className="flex flex-col items-center">
                             <User size={32} className="text-blue-500 mb-1" />
                             <h2 className="text-2xl md:text-4xl font-black font-urban text-blue-400 text-center uppercase leading-none break-words">
                                 {rivalA || "MC AZUL"}
                             </h2>
                         </div>
                         <div className="hidden md:block w-1 h-16 bg-blue-500/50 rounded-full my-4"></div>
                         <div className="text-xs text-blue-300 font-bold uppercase tracking-widest rotate-0 md:-rotate-90 whitespace-nowrap">RIVAL 1</div>
                    </div>

                    {/* MIDDLE COLUMN: GENERATOR + CONTROLS */}
                    <div className="w-full md:w-1/2 flex flex-col gap-4 order-1 md:order-2 h-full justify-center">
                        
                        {/* Battle Info Header */}
                        <div className="bg-black/60 border-l-4 border-yellow-500 rounded-r-lg p-3 flex justify-between items-center shadow-lg">
                            <div className="flex flex-col">
                                <span className="text-gray-400 text-xs font-bold uppercase tracking-wider">Formato</span>
                                <span className="text-yellow-400 font-urban text-lg leading-none">{selectedFormat}</span>
                            </div>
                            <div className="flex items-center gap-2 bg-yellow-500/10 px-3 py-1 rounded-full border border-yellow-500/30">
                                <Timer size={16} className="text-yellow-400" />
                                <span className="text-white font-bold uppercase text-sm tracking-wide">
                                    {selectedFormat ? ENTRADAS_RULES[selectedFormat] : "5 Entradas"}
                                </span>
                            </div>
                        </div>

                        <TopicGenerator 
                            mode={selectedMode} 
                            initialTopic={preGeneratedTopic}
                            initialImage={preGeneratedImage}
                            initialPool={preGeneratedPool}
                        />

                        {/* CONTROLS (Directly under the box) */}
                        <div className="flex flex-col gap-2 w-full mt-2">
                            <button 
                                onClick={handleFinishBattle}
                                disabled={isGeneratingVotingBg}
                                className={`w-full py-4 rounded-xl font-black text-xl uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-[0_0_20px_rgba(37,99,235,0.4)] border-b-4 border-purple-900 ${
                                    isGeneratingVotingBg
                                    ? 'bg-gray-800 text-gray-500 cursor-wait'
                                    : 'bg-gradient-to-r from-blue-600 to-red-600 text-white hover:scale-105 active:scale-95'
                                }`}
                            >
                                {isGeneratingVotingBg ? (
                                    <>
                                        <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-gray-500"></div>
                                        PREPARANDO JURADO...
                                    </>
                                ) : (
                                    <>
                                        <Trophy size={24} />
                                        TERMINAR BATALLA
                                    </>
                                )}
                            </button>

                            <button 
                                onClick={resetApp}
                                className="text-purple-500 hover:text-white transition-colors flex items-center justify-center gap-2 text-xs uppercase font-bold tracking-widest opacity-60 hover:opacity-100 py-2"
                            >
                                <RotateCcw size={14} />
                                Terminar
                            </button>
                        </div>
                    </div>

                    {/* RIGHT COLUMN: RIVAL B */}
                    <div className="w-full md:w-1/4 flex md:flex-col justify-between md:justify-center items-center order-3 md:order-3 gap-2 bg-red-900/10 border border-red-500/20 rounded-xl p-2 md:p-4">
                         <div className="flex flex-col items-center">
                             <User size={32} className="text-red-500 mb-1" />
                             <h2 className="text-2xl md:text-4xl font-black font-urban text-red-400 text-center uppercase leading-none break-words">
                                 {rivalB || "MC ROJO"}
                             </h2>
                         </div>
                         <div className="hidden md:block w-1 h-16 bg-red-500/50 rounded-full my-4"></div>
                         <div className="text-xs text-red-300 font-bold uppercase tracking-widest rotate-0 md:rotate-90 whitespace-nowrap">RIVAL 2</div>
                    </div>

                </div>
            )}

            {/* STEP 6: VOTING (NEON JESTER EDITION) */}
            {step === 'voting' && (
                <div className="fixed inset-0 z-50 flex overflow-hidden bg-black animate-fadeIn">
                    
                    {/* BACKGROUND GRID TEXTURE */}
                    <div className="absolute inset-0 bg-[linear-gradient(rgba(20,20,30,0.9)_1px,transparent_1px),linear-gradient(90deg,rgba(20,20,30,0.9)_1px,transparent_1px)] bg-[size:40px_40px] opacity-20 pointer-events-none"></div>

                    {/* REDESIGNED WINNER OVERLAY (CARD STYLE) */}
                    {showWinnerScreen && winner && (
                         <div className={`absolute inset-0 z-[60] flex items-center justify-center animate-fadeIn bg-black/90`}>
                             
                             {/* Background Particles/Glow */}
                             <div className="absolute inset-0 overflow-hidden pointer-events-none">
                                <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full blur-[150px] opacity-40 ${winner === 'A' ? 'bg-blue-600' : 'bg-red-600'}`}></div>
                                <div className="absolute inset-0 bg-noise opacity-10"></div>
                             </div>

                             {/* MAIN WINNER CARD */}
                             <div className={`relative w-full max-w-md md:max-w-lg bg-black border-4 rounded-3xl p-8 flex flex-col items-center shadow-[0_0_80px_rgba(0,0,0,0.8)] animate-scale-up z-10 overflow-hidden ${winner === 'A' ? 'border-blue-500 shadow-[0_0_50px_rgba(37,99,235,0.4)]' : 'border-red-500 shadow-[0_0_50px_rgba(220,38,38,0.4)]'}`}>
                                 
                                 {/* Decorative Ribbons */}
                                 <div className={`absolute top-0 right-0 w-32 h-32 transform translate-x-16 -translate-y-16 rotate-45 ${winner === 'A' ? 'bg-blue-600' : 'bg-red-600'}`}></div>
                                 <div className={`absolute bottom-0 left-0 w-32 h-32 transform -translate-x-16 translate-y-16 rotate-45 ${winner === 'A' ? 'bg-blue-600' : 'bg-red-600'}`}></div>

                                 {/* Winner Badge */}
                                 <div className="mb-6 relative">
                                    <div className={`absolute inset-0 blur-[30px] ${winner === 'A' ? 'bg-blue-400' : 'bg-red-400'}`}></div>
                                    <Crown size={80} className={`relative z-10 ${winner === 'A' ? 'text-blue-100' : 'text-red-100'}`} fill="currentColor" />
                                    <Star size={30} className="absolute -top-4 -right-4 text-yellow-400 animate-bounce" fill="currentColor" />
                                    <Star size={20} className="absolute top-10 -left-6 text-yellow-400 animate-pulse" fill="currentColor" />
                                 </div>

                                 <h3 className="text-gray-400 font-bold uppercase tracking-[0.3em] text-xs mb-2">VICTORIA MAGISTRAL</h3>
                                 
                                 <h2 className={`text-6xl font-black font-urban text-center uppercase leading-none mb-6 break-words w-full ${winner === 'A' ? 'text-blue-500 drop-shadow-[0_0_15px_rgba(59,130,246,0.8)]' : 'text-red-500 drop-shadow-[0_0_15px_rgba(220,38,38,0.8)]'}`}>
                                     {winner === 'A' ? rivalA : rivalB}
                                 </h2>

                                 <div className={`w-full h-1 mb-8 ${winner === 'A' ? 'bg-blue-900' : 'bg-red-900'}`}></div>

                                 <div className="flex flex-col gap-2 items-center mb-8">
                                     <Award size={32} className="text-yellow-500 mb-2" />
                                     <span className="text-white font-urban text-2xl uppercase tracking-widest">REY DE LA CORTE</span>
                                 </div>

                                 <button 
                                    onClick={resetApp}
                                    className={`w-full py-4 rounded-xl font-bold uppercase tracking-widest text-white transition-all transform hover:scale-105 active:scale-95 flex items-center justify-center gap-2 ${winner === 'A' ? 'bg-blue-600 hover:bg-blue-500' : 'bg-red-600 hover:bg-red-500'}`}
                                 >
                                    <RotateCcw size={20} />
                                    NUEVA BATALLA
                                 </button>
                             </div>
                         </div>
                    )}

                    {/* BLUE SIDE (LEFT) */}
                    <div 
                        onClick={() => !winner && handleVote('A')}
                        className={`absolute top-0 left-0 w-full h-full flex flex-col justify-start items-start p-6 md:p-12 cursor-pointer group z-10 [clip-path:polygon(0_0,100%_0,100%_45%,0_55%)] md:[clip-path:polygon(0_0,60%_0,40%_100%,0%_100%)] overflow-hidden transition-all duration-700 ease-in-out ${winner === 'B' ? 'grayscale z-0 animate-execution' : ''}`}
                    >
                         {/* Neon Background Glow */}
                         <div className="absolute inset-0 bg-blue-950 transition-colors duration-300 group-hover:bg-blue-900"></div>
                         
                         {/* Holographic Image Layer - CENTERED */}
                         <div className="absolute inset-0 z-0 opacity-80 mix-blend-screen transition-all duration-500 group-hover:scale-105 group-hover:opacity-100">
                             <img 
                                src={bgToUse} 
                                className="w-full h-full object-cover object-center grayscale brightness-50 contrast-150" 
                                style={{filter: 'drop-shadow(0 0 10px blue)'}} 
                                alt="" 
                             />
                             {/* Pure Blue Overlay for Neon Look */}
                             <div className="absolute inset-0 bg-blue-600 mix-blend-color-dodge opacity-50"></div>
                         </div>
                         
                         {/* Top-Left Anchor */}
                         <div className="absolute top-2 left-2 md:top-8 md:left-8 z-10 text-left max-w-[50%] transition-transform duration-300 group-hover:translate-x-4">
                             <User size={60} className="text-blue-400 mb-2 opacity-80 group-hover:opacity-100 drop-shadow-[0_0_10px_rgba(59,130,246,0.8)]" />
                             <h2 className="text-4xl md:text-7xl font-urban font-black text-transparent bg-clip-text bg-gradient-to-t from-blue-600 to-white drop-shadow-[0_0_15px_rgba(59,130,246,0.8)] break-words leading-none uppercase">
                                 {rivalA}
                             </h2>
                             {!winner && <p className="text-blue-300 font-bold tracking-[0.5em] mt-4 opacity-0 group-hover:opacity-100 transition-opacity animate-pulse border-b-2 border-blue-400 inline-block">SELECCIONAR</p>}
                         </div>
                    </div>

                    {/* RED SIDE (RIGHT) */}
                    <div 
                        onClick={() => !winner && handleVote('B')}
                        className={`absolute top-0 left-0 w-full h-full flex flex-col justify-end items-end p-6 md:p-12 cursor-pointer group z-10 [clip-path:polygon(0_55%,100%_45%,100%_100%,0%_100%)] md:[clip-path:polygon(60%_0,100%_0,100%_100%,40%_100%)] overflow-hidden transition-all duration-700 ease-in-out ${winner === 'A' ? 'grayscale z-0 animate-execution' : ''}`}
                    >
                         {/* Neon Background Glow */}
                         <div className="absolute inset-0 bg-red-950 transition-colors duration-300 group-hover:bg-red-900"></div>

                         {/* Holographic Image Layer - CENTERED */}
                         <div className="absolute inset-0 z-0 opacity-80 mix-blend-screen transition-all duration-500 group-hover:scale-105">
                             <img 
                                src={bgToUse} 
                                className="w-full h-full object-cover object-center grayscale brightness-50 contrast-150" 
                                style={{filter: 'drop-shadow(0 0 10px red)'}} 
                                alt="" 
                             />
                             {/* Pure Red Overlay for Neon Look */}
                             <div className="absolute inset-0 bg-red-600 mix-blend-color-dodge opacity-50"></div>
                         </div>

                         {/* Bottom-Right Anchor */}
                         <div className="absolute bottom-2 right-2 md:bottom-8 md:right-8 z-10 text-right max-w-[50%] transition-transform duration-300 group-hover:-translate-x-4">
                             <User size={60} className="text-red-400 ml-auto mb-2 opacity-80 group-hover:opacity-100 drop-shadow-[0_0_10px_rgba(220,38,38,0.8)]" />
                             <h2 className="text-4xl md:text-7xl font-urban font-black text-transparent bg-clip-text bg-gradient-to-t from-red-600 to-white drop-shadow-[0_0_15px_rgba(220,38,38,0.8)] break-words leading-none uppercase">
                                 {rivalB}
                             </h2>
                             {!winner && <p className="text-red-300 font-bold tracking-[0.5em] mt-4 opacity-0 group-hover:opacity-100 transition-opacity animate-pulse border-b-2 border-red-400 inline-block">SELECCIONAR</p>}
                         </div>
                    </div>

                    {/* NEON SPLIT DIVIDER */}
                    <div className="absolute inset-0 pointer-events-none z-30 hidden md:block">
                        <div className="absolute top-0 left-[60%] w-1 h-full bg-white blur-[2px] opacity-50 origin-top -skew-x-[22deg]"></div>
                        <div className="absolute top-0 left-[60%] w-[2px] h-full bg-purple-400 opacity-80 origin-top -skew-x-[22deg] shadow-[0_0_20px_rgba(192,38,211,1)]"></div>
                    </div>

                    {/* VS CENTER - UPDATED FOR REPLICA */}
                    {!winner && (
                         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 flex flex-col items-center gap-4">
                             <div className="pointer-events-none mb-2">
                                <h1 className="text-9xl font-black font-urban text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-500 italic drop-shadow-[0_0_30px_rgba(255,255,255,0.5)] opacity-80">VS</h1>
                             </div>
                             
                             <button
                                onClick={handleReplica}
                                className="group relative px-6 py-3 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/30 rounded-full font-bold uppercase tracking-[0.3em] text-sm md:text-base transition-all hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(255,255,255,0.2)]"
                             >
                                <div className="flex items-center gap-2">
                                    <Scale size={18} />
                                    RÉPLICA
                                </div>
                                <div className="absolute -inset-1 rounded-full border border-white/50 opacity-0 group-hover:opacity-100 animate-ping"></div>
                             </button>
                         </div>
                    )}
                </div>
            )}

        </main>

        {/* Footer - Hide in Voting */}
        {step !== 'voting' && (
            <footer className="text-center text-purple-500/60 text-xs py-8 flex flex-col items-center gap-2 mt-auto">
                <div className="flex items-center gap-2 bg-purple-950/30 px-4 py-2 rounded-full border border-purple-900/50">
                    <Info size={12} />
                    <p>Potenciado por Google Gemini 2.5 Flash & Flash Image</p>
                </div>
                <p>© 2024 La Corte del Rey. Diseñado para improvisadores.</p>
            </footer>
        )}
      </div>

      <style>{`
        /* ANIMATED SHINE TEXT - BLUE TO RED with MOVING WHITE SHINE */
        .animate-shine-text {
            background: linear-gradient(
                110deg,
                #2563eb 0%,   /* Blue */
                #2563eb 40%,  /* Blue */
                #ffffff 50%,  /* Shine */
                #dc2626 60%,  /* Red */
                #dc2626 100%  /* Red */
            );
            background-size: 200% auto;
            color: transparent;
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: shine 4s linear infinite;
        }

        @keyframes shine {
            to {
                background-position: 200% center;
            }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn {
            animation: fadeIn 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) forwards;
        }
        @keyframes fadeInFast {
            animation: fadeIn 0.2s ease-out forwards;
        }
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        .animate-float {
            animation: float 3s ease-in-out infinite;
        }
        @keyframes scale-up {
            0% { transform: scale(0.5); opacity: 0; }
            50% { transform: scale(1.1); opacity: 1; }
            100% { transform: scale(1); opacity: 1; }
        }
        .animate-scale-up {
            animation: scale-up 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
        }
        @keyframes flash-storm {
            0% { opacity: 0; }
            20% { opacity: 1; } /* SOLID OPACITY AT PEAK */
            40% { opacity: 1; } /* HOLD OPACITY */
            100% { opacity: 0; }
        }
        .animate-flash-storm {
            animation: flash-storm 0.8s ease-out forwards;
        }
        @keyframes strike {
            0% { transform: scale(0.5) rotate(-10deg); opacity: 0; }
            20% { opacity: 1; transform: scale(1.2) rotate(5deg); }
            40% { transform: scale(1) rotate(0deg); }
            100% { transform: scale(1.5) rotate(10deg); opacity: 0; }
        }
        .animate-strike {
            animation: strike 0.6s ease-out forwards;
        }
        @keyframes execution {
            0% { transform: translateY(0); opacity: 1; filter: grayscale(100%); }
            15% { transform: translate(5px, 0) rotate(1deg); filter: grayscale(100%) brightness(1.5); } /* Flash shock */
            30% { transform: translate(-5px, 0) rotate(-1deg); filter: grayscale(100%) brightness(0.8) sepia(1) hue-rotate(-50deg) saturate(3); } /* Turn Red/Bleed */
            40% { transform: translateY(10px) scale(0.98); } /* Anticipate drop */
            100% { transform: translateY(200%) rotate(5deg); opacity: 0; filter: grayscale(100%) brightness(0); } /* Drop to abyss */
        }
        .animate-execution {
            animation: execution 2.5s cubic-bezier(0.55, 0.055, 0.675, 0.19) forwards;
        }
        .bg-noise {
            background-image: repeating-linear-gradient(
                0deg,
                transparent,
                transparent 1px,
                #fff 1px,
                #fff 2px
            );
            background-size: 100% 4px;
        }
        .custom-scrollbar::-webkit-scrollbar {
            width: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: rgba(0,0,0,0.3);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #a855f7;
            border-radius: 4px;
        }
      `}</style>
    </div>
  );
};

export default App;
